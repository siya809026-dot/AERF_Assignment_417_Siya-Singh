# part A:

# What is an ADT?
# An Abstract Data Type (ADT) is a logical model that defines how data is organized and what operations can be performed on it,
# without specifying how those operations are implemented. It focuses on what the data structure does rather than how it does it.
# Examples include Stack, Queue, List, and Tree. ADTs help in designing clean and modular programs.

# Why are stack operations usually O(1)?
# Stack operations such as push and pop take constant time because they only add or remove an element from the top of the stack.
# No shifting or traversal of elements is required. The top position is directly accessible, making each operation independent of the stack size. 
# Therefore, their time complexity remains O(1) (constant time).

# Part B:

# Question 4: Analysis of Factorial and Fibonacci (Simple Language)
# This section analyzes the Factorial and Fibonacci problems using recursion.
# We discuss time complexity, space complexity, and use Big-O, Big-Ω, and Big-Θ notations wherever meaningful.
# We also explain why naive Fibonacci becomes slow for large values of n.
# 1. Factorial
# The factorial of a number n is defined as:
# Recursive Definition
# Time Complexity (Factorial)
# The function makes exactly one recursive call for each value from n down to 1.
# Total number of calls = n.
# Since the number of operations is always proportional to n:
# Best Case: Ω(n)
# Worst Case: O(n)
# Average Case: Θ(n)
# Space Complexity (Factorial)
# Each recursive call uses stack memory.
# Maximum recursion depth = n.
# 2. Fibonacci
# The Fibonacci sequence is defined as:
# F(n)=F(n-1)+F(n-2),\quad n \ge 2 
# Two approaches are considered:
# Naive Recursive Fibonacci
# Memoized Fibonacci
# 2.1 Naive Recursive Fibonacci
# Time Complexity
# Each call makes two recursive calls.
# The recursion tree grows exponentially.
# Many subproblems are recomputed repeatedly.
# Since the number of calls always grows exponentially:
# Best Case: Ω(2ⁿ)
# Worst Case: O(2ⁿ)
# Average Case: Θ(2ⁿ)
# Space Complexity (Naive Fibonacci)
# Maximum recursion depth = n
# Stack space increases linearly
# Why Naive Fibonacci Becomes Slow for Large n
# Naive Fibonacci is slow because of repeated calculations.
# Example:
# To compute F(5), the function calculates:
# F(4) and F(3)
# F(4) again calculates:
# F(3) and F(2)
# F(3) is computed multiple times
# This causes:
# Exponential growth in function calls
# Huge increase in execution time for large n
# Very poor performance after n > 30
# Therefore, naive Fibonacci is inefficient for large values of n.
# 2.2 Memoized Fibonacci
# Memoization stores already computed Fibonacci values and reuses them.
# Time Complexity (Memoized Fibonacci)
# Each Fibonacci value from 0 to n is computed only once.
# Since every case performs linear work:
# Best Case: Ω(n)
# Worst Case: O(n)
# Average Case: Θ(n)
# Space Complexity (Memoized Fibonacci)
# Recursive call stack = O(n)
# Extra array (memo table) = O(n)
# 3. Comparison Summary
# Algorithm
# Time Complexity
# Space Complexity
# Efficiency
# Factorial (Recursive)
# O(n)
# O(n)
# Efficient
# Fibonacci (Naive)
# O(2ⁿ)
# O(n)
# Very Slow
# Fibonacci (Memoized)
# O(n)
# O(n)
# Efficient
# Conclusion
# Factorial has linear time and space complexity and works efficiently.
# Naive Fibonacci suffers from exponential time complexity due to repeated recursive calls.
# Memoized Fibonacci avoids repetition and reduces time complexity to O(n).
# This analysis clearly shows why optimization is necessary in recursive algorithms.

# Part C :

# Why the Number of Moves Becomes 
# In the Tower of Hanoi problem, to move n disks from the source peg to the destination peg using an auxiliary peg, the problem is solved recursively.
# To move n disks:
# Move the top (n − 1) disks from the source peg to the auxiliary peg.
# Move the largest disk (nth disk) from the source peg to the destination peg.
# Move the (n − 1) disks from the auxiliary peg to the destination peg.
# Let be the number of moves required for n disks.
# T(n) = 2T(n-1) + 1 
# With the base case:
# Solving this recurrence relation gives:
# Therefore, the total number of moves required to solve the Tower of Hanoi problem with n disks is:
# Time Complexity
# Since the algorithm performs exactly � moves, the time taken grows exponentially with the number of disks.
# Each move takes constant time, and the total number of moves dominates the execution time.
# Space Complexity
# The Tower of Hanoi solution uses recursion.
# The maximum depth of the recursive call stack is n, corresponding to the number of disks.
# No additional data structures are used apart from recursion.
# Conclusion
# The number of moves increases exponentially as the number of disks increases.
# Tower of Hanoi is an example of a recursive problem with exponential time complexity.
# It clearly demonstrates the trade-off between simplicity of recursive logic and performance cost.

# Part D:
# Question 2: Handle Edge Cases
# When implementing Binary Search, certain special situations (edge cases) must be handled to ensure correctness.
# 1. Empty List
# If the input array is empty (arr = []), there are no elements to search.
# Binary search should immediately return “key not found” (usually -1).
# This avoids invalid index access and unnecessary computation.
# Reason:
# Binary search works by repeatedly dividing the search space. If the list is empty, the search space size is zero, so the algorithm must terminate immediately.
# 2. Key Not Present
# If the key does not exist in the array, binary search will keep reducing the search range.
# Eventually, the low index becomes greater than the high index.
# At this point, the algorithm concludes that the key is not present and returns “not found”.
# Reason:
# Binary search eliminates half of the remaining elements at each step. If all possibilities are eliminated without finding the key, it proves the key does not exist in the array.
# Question 3: Time Complexity Explanation Using Recurrence
# Binary search repeatedly divides the array into two halves.
# Recurrence Relation
# Explanation
# At each step, the algorithm:
# Compares the middle element (O(1) time).
# Discards half of the array.
# The problem size reduces from n to n/2, then n/4, n/8, and so on.
# After k steps:
# Final Time Complexity
# Best, Average, and Worst Case Analysis
# Best Case
# The key is found at the middle element in the first comparison.
# Time Complexity:
# Average Case
# The key is found after several divisions of the array.
# Time Complexity:
# Worst Case
# The key is either at the extreme end of the array or not present at all.
# The algorithm performs maximum comparisons.
# Time Complexity:
# Summary Table
# Case
# Condition
# Time Complexity
# Best Case
# Key found at middle
# O(1)
# Average Case
# Key found after several steps
# O(log n)
# Worst Case
# Key not found or at last position
# O(log n)

# Part E: 

# 1. Why Binary Search is Divide & Conquer
# Binary Search follows the Divide and Conquer paradigm because it repeatedly divides the problem into smaller subproblems and solves them independently.
# In binary search, the given sorted array is divided into two halves by checking the middle element.
# If the key is equal to the middle element, the search ends.
# If the key is smaller, the left half is searched.
# If the key is larger, the right half is searched.
# At every step, the problem size is reduced to half. This process continues recursively until the element is found or the search space becomes empty.
# Thus, binary search clearly uses divide (split the array), conquer (solve smaller subproblem), and combine (return result) steps, which makes it a Divide & Conquer algorithm.

# 2. Why Memoized Fibonacci is Dynamic Programming
# Memoized Fibonacci is an example of Dynamic Programming because it solves the problem by storing results of overlapping subproblems and reusing them.
# In naive Fibonacci recursion, the same Fibonacci values are calculated again and again, which causes a large number of recursive calls and poor performance.
# Memoization solves this problem by storing already computed Fibonacci values in memory (such as an array or dictionary). When the same value is needed again, it is directly fetched instead of recomputing it.
# This approach avoids repeated work and improves time complexity from exponential to linear.
# Hence, memoized Fibonacci uses optimal substructure and overlapping subproblems, which are the key characteristics of Dynamic Programming.

# 3. How Tower of Hanoi Uses Recursion
# The Tower of Hanoi problem is a classic example of recursion because it breaks a large problem into smaller similar subproblems.
# Base Case
# When there is only one disk, it can be moved directly from the source rod to the destination rod.
# Recursive Case
# To move n disks:
# Move n−1 disks from source to auxiliary rod.
# Move the largest disk from source to destination.
# Move n−1 disks from auxiliary to destination rod.
# Each step reduces the problem size until the base case is reached.
# This repeated reduction makes Tower of Hanoi a perfect example of recursion.

# 4. Real-Life Examples of Paradigms
# Divide & Conquer (Real-Life Example)
# Searching for a word in a dictionary:
# Open the dictionary in the middle
# Decide whether the word lies in the left or right half
# Repeat the process on the selected half
# This is similar to binary search.

# Dynamic Programming (Real-Life Example)
# Planning travel expenses:
# You calculate and store minimum cost routes
# When the same route is needed again, you reuse the stored result
# This avoids recalculating costs repeatedly

# Greedy Algorithm (Real-Life Example)
# Giving change using the largest currency notes first:
# Always give the highest denomination possible
# This decision is made at each step without reconsidering past choices
# Greedy algorithms make locally optimal decisions hoping to reach a global optimum.
# Conclusion
# Different algorithmic paradigms are suitable for different types of problems.
# Divide & Conquer efficiently reduces problem size
# Dynamic Programming avoids repeated computation
# Recursion simplifies complex problems
# Greedy algorithms provide fast and simple solutions

# Understanding these paradigms helps in choosing the right approach for problem solving.

