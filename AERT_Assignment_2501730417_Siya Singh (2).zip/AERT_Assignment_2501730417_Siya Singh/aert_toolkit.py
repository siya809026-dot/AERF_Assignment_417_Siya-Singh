#<------------------ part A: 1. implement a StackADT class with these operation--------------------->
class StackADT:
    def __init__(self):
        self.stack = []

    # Push element onto stack
    def push(self, x):
        self.stack.append(x)
        print(f"{x} pushed into stack")

    # Pop element from stack
    def pop(self):
        if self.is_empty():
            print("Stack is empty. Cannot pop.")
        else:
            removed = self.stack.pop()
            print(f"{removed} popped from stack")
            return removed

    # Peek top element
    def peek(self):
        if self.is_empty():
            print("Stack is empty. Nothing to peek.")
        else:
            print(f"Top element is: {self.stack[-1]}")
            return self.stack[-1]

    # Check if stack is empty
    def is_empty(self):
        return len(self.stack) == 0

    # Return size of stack
    def size(self):
        print(f"Size of stack is: {len(self.stack)}")
        return len(self.stack)


# ------------------ OUTPUT DEMONSTRATION ------------------

s = StackADT()

s.push(10)
s.push(20)
s.push(30)

s.peek()

s.size()

s.pop()
s.pop()

s.size()

s.pop()
s.pop()   # Trying to pop from empty stack
#<----------------------3.Use your stack StackADT in atleast one place---------------->
class StackADT:
    def __init__(self):
        self.stack = []

    def push(self, x):
        self.stack.append(x)

    def pop(self):
        if not self.is_empty():
            return self.stack.pop()

    def peek(self):
        if not self.is_empty():
            return self.stack[-1]

    def is_empty(self):
        return len(self.stack) == 0

    def size(self):
        return len(self.stack)


# ---------------- Using StackADT for Recursion Trace ----------------

trace_stack = StackADT()

def fibonacci(n):
    trace_stack.push(f"fibonacci({n}) called")
    
    if n <= 1:
        trace_stack.push(f"fibonacci({n}) returns {n}")
        return n
    
    result = fibonacci(n-1) + fibonacci(n-2)
    
    trace_stack.push(f"fibonacci({n}) returns {result}")
    return result


# ----------- Driver Code ------------

n = 4
result = fibonacci(n)

print("Fibonacci Result:", result)

print("\nRecursion Trace (Stack Contents):")
while not trace_stack.is_empty():
    print(trace_stack.pop())

#< -------------partB------------------>

# 1. Factorial (Recursive)
# -------------------------------

def factorial(n):
    if n < 0:
        return "Invalid input"
    if n == 0:
        return 1
    return n * factorial(n - 1)


print("FACTORIAL OUTPUTS")
print("n = 0 ->", factorial(0))
print("n = 1 ->", factorial(1))
print("n = 5 ->", factorial(5))
print("n = 10 ->", factorial(10))

print("\n-------------------------------\n")
# Question:
# Part B – Question 2
# Fibonacci (Two Versions)
# Write fib_naive(n): simple recursive Fibonacci

def fib_naive(n):
    if n == 0 or n == 1:
        return n
    return fib_naive(n-1) + fib_naive(n-2)

n = 5
print("Fibonacci(", n, ") =", fib_naive(n))

# Question:
# Part B – Question 2
# Fibonacci (Two Versions)
# Write fib_memo(n): recursive Fibonacci with memoization

memo = {}

def fib_memo(n):
    if n in memo:
        return memo[n]

    if n == 0 or n == 1:
        memo[n] = n
    else:
        memo[n] = fib_memo(n-1) + fib_memo(n-2)

    return memo[n]

n = 5
print("Fibonacci(", n, ") =", fib_memo(n))

# Question:
# Part B – Question 3
# Call Counter Requirement (Must)
# Add a counter to show how many recursive calls happen in naive Fibonacci

naive_calls = 0

def fib_naive(n):
    global naive_calls
    naive_calls += 1

    if n == 0 or n == 1:
        return n
    return fib_naive(n-1) + fib_naive(n-2)

n = 5
naive_calls = 0
result = fib_naive(n)

print("Fibonacci(", n, ") =", result)
print("Naive Fibonacci Call Count =", naive_calls)

# Question:
# Part B – Question 3
# Call Counter Requirement (Must)
# Add a counter to show how many recursive calls happen in memoized Fibonacci
# Global counter for memoized Fibonacci calls
memo_calls = 0

def fib_memo(n, memo):
    global memo_calls
    memo_calls += 1

    # If value already computed, return it
    if n in memo:
        return memo[n]

    # Base cases
    if n <= 1:
        memo[n] = n
        return n

    # Recursive calls with memoization
    memo[n] = fib_memo(n - 1, memo) + fib_memo(n - 2, memo)
    return memo[n]


# Testing memoized Fibonacci
test_values = [5, 10, 20, 30]

for n in test_values:
    memo_calls = 0
    memo = {}

    result = fib_memo(n, memo)

    print("Fibonacci output for n =", n)
    print("Memoized Fibonacci Result:", result)
    print("Memoized Recursive Calls:", memo_calls)
    print("--------------------------------")
# 4.Required test case

test_values = [5, 10, 20, 30]

for n in test_values:
    naive_calls = 0
    memo_calls = 0
    memo = {}

    naive_result = fib_naive(n)
    memo_result = fib_memo(n, memo)

    print("FIBONACCI OUTPUTS FOR n =", n)
    print("Naive Fibonacci Result:", naive_result)
    print("Naive Recursive Calls:", naive_calls)
    print("Memoized Fibonacci Result:", memo_result)
    print("Memoized Recursive Calls:", memo_calls)
    print("----------------------------------")

fact_calls = 0
def factorial(n):
    global fact_calls
    fact_calls += 1

    if n == 0:
        return 1
    return n * factorial(n - 1)


# Testing factorial
for n in [5, 10]:
    fact_calls = 0
    result = factorial(n)
    print("Factorial of", n, "=", result)
    print("Total Recursive Calls =", fact_calls)
    print("---------------------------")

    # Part C – Tower of Hanoi
# Implement hanoi(n, source, auxiliary, destination) using recursion

def hanoi(n, source, auxiliary, destination):
    if n == 1:
        print(f"Move disk 1 from {source} to {destination}")
        return

    hanoi(n - 1, source, destination, auxiliary)
    print(f"Move disk {n} from {source} to {destination}")
    hanoi(n - 1, auxiliary, source, destination)

    # Print exact sequence of moves for N = 3
hanoi(3, 'A', 'B', 'C')

# binary_search(arr, key, low, high)
# Part D – Recursive Binary Search
# Implement binary_search(arr, key, low, high)
# Return index if found, else return -1

def binary_search(arr, key, low, high):
    if low > high:
        return -1

    mid = (low + high) // 2

    if arr[mid] == key:
        return mid
    elif key < arr[mid]:
        return binary_search(arr, key, low, mid - 1)
    else:
        return binary_search(arr, key, mid + 1, high)
    
    # Test cases

arr = [1, 3, 5, 7, 9, 11, 13]
keys = [7, 1, 13, 2]

for key in keys:
    result = binary_search(arr, key, 0, len(arr) - 1)
    print("Search key:", key, "-> Result index:", result)

# Empty array test
empty_arr = []
print("Empty array search:", binary_search(empty_arr, 5, 0, len(empty_arr) - 1))